These are some examples of AES encrypted shells with they keys and IV's given

Sniper Snague Shell:
key: hackedbyssnague
iv: lmao

B374k Mini Shell
key: sp00ki
iv: anthrax
