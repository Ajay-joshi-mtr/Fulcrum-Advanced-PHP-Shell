_______ _     _        _______  ______ _     _ _______       _____  _     _  _____       _______ _     _ _______
|______ |     | |      |       |_____/ |     | |  |  |      |_____] |_____| |_____]      |______ |_____| |______ |      |
|       |_____| |_____ |_____  |    \_ |_____| |  |  |      |       |     | |            ______| |     | |______ |_____ |_____

                                                    By Anthrax and Drigg3r
                                                          Osmium Group

This Shell is like an outer cover for your PHP webshells, to protect them from being copied and detected

We have used some special methods to reduce the size of every webshell to less then 200 bytes

Refer to instructions.txt for all the shell instructions

Thanks for using Fulcrum PHP Shell

Conatct us at

XMPP: SniperSnague@xmpp.jp
XMPP: webshell@wtfismyip.com
